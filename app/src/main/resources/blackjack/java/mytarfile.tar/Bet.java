/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjackdev.java;

/**
 *
 * @author Mark
 */

//import BlackJackView;

import android.graphics.*;
import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.lang.Math.*;

public class Bet extends TextView{
    private int x;
    private int y;
    private BlackJackDevActivity that;
    private Bank bank;
    //private int betValue = 0;
    private int value = 0;
    private RelativeLayout layout;
    private RelativeLayout.LayoutParams rl;
    
    public Bet(int myX, int myY, BlackJackDevActivity myThat, Bank myBank, RelativeLayout myLayout, Context context) 
    {
    	super(context);
        x = myX;
        y = myY;
        that = myThat;
        bank = myBank;
        layout = myLayout;
        rl = getRL(x, y);
        TextView up = new TextView(that);
		up.setText("U");
		up.setTextColor(Color.BLACK);
		up.setWidth(30);
		up.setHeight(30);
		layout.addView(up, getRL(x , y + 32));
		up.setBackgroundColor(Color.GREEN);
		up.setGravity(Gravity.CENTER_HORIZONTAL);
		TextView down = new TextView(that);
		down.setText("D");
		down.setTextColor(Color.BLACK);
		down.setWidth(30);
		down.setHeight(30);
		layout.addView(down, getRL(x + 30, y + 32));
		down.setBackgroundColor(Color.RED);
		down.setGravity(Gravity.CENTER_HORIZONTAL);
		
        this.setBackgroundColor(Color.WHITE);
        this.setWidth(60);
		this.setGravity(Gravity.CENTER_HORIZONTAL);
        Typeface tf = Typeface.create("Helvetica", 1);
        this.setTypeface(tf);
		up.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0)
			{
				wager(5);
			}
		});
		
		down.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0)
			{
				wager(-5);
			}
		});
    	layout.addView(this, rl);
    }
   
    public void wager(int howmuch)
    {
        if (howmuch < 0 && value < -howmuch)
            return;
//        if (Math.abs(howmuch) > betValue)
  //          return;
        if (howmuch > 0)
            value += bank.withdraw(howmuch);
        else
            value -= bank.deposit(-howmuch);
        setText(Integer.toString(value));
        setBackgroundColor(Color.WHITE);
        this.setTextColor(Color.BLACK);
    }

    public void win()
    {
        //bank.Deposit(2 * betValue);
        value *= 2;
        
        setBackgroundColor(Color.GREEN);
        setText(Integer.toString(value));
    }
    
    public void lose()
    {
        value = 0;
        
        setBackgroundColor(Color.RED);
        setText(Integer.toString(value));
    }
    
    public void push()
    {
        //betValue = 0;
        //bank.Deposit(betValue);
        setText(Integer.toString(value));
    }
    
	/*
    public int getBet()
    {
        return value;
    }
	*/
    
    public int setBet(int savedBet)
    {
        value = savedBet;
        return value;
    }
    
	/*
    public void SetColor(Color c)
    {
        //setBackgroundColor(c);
    }
    
    public void DiscardBet()
    {
        layout.removeView(this);
    }
	*/
    
	private RelativeLayout.LayoutParams getRL(int x, int y)
	{
		RelativeLayout.LayoutParams rl = new
			RelativeLayout.LayoutParams(
					RelativeLayout.LayoutParams.WRAP_CONTENT,
					RelativeLayout.LayoutParams.WRAP_CONTENT);
		rl.topMargin = y;
		rl.leftMargin = x;
		return rl;
	}
}
