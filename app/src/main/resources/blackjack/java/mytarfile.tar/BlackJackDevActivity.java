package blackjackdev.java;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;

public class BlackJackDevActivity extends Activity {
    /** Called when the activity is first created. */
	private static final String cardsDir = "/data/data/blackjackdev.java/cards/%s.png";
	
	private Shoe shoe;
	private RelativeLayout layout;
	private int deltax = 0, deltay = 0;
	private int deltaval = 15;

	private int numPlayers = 4;
    private int numHands = 4;
	private ArrayList<Player> players;
	private Player player;	// Current player
	private Player dealer;	// Last player, namely, dealer
    private Hand dealerHand;
    private int curHandX;
//    private BlkJkPack mypack = new BlkJkPack();
    private TextView bets;
    private TextView balances;
    private String redealPath;
    private Button placeBetsButton;
    private Button dealCardsButton;
    private Button saveGameButton;
    private Button redealHandsButton;
    private boolean redealt;
    public int dealerHandResult;
    public boolean dealerBlackJack = false;
	private long msInc = 50;
	private final Handler handler = new Handler();

    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        layout = new RelativeLayout(this);
		players = new ArrayList<Player>();
		shoe = new Shoe(3, cardsDir);
		Button dealCardsBtn = new Button(this);
		dealCardsBtn.setText("Deal Cards");
		redealt = false;
		layout.addView(dealCardsBtn, getRL(0,600));
		Button saveGameButton = new Button(this);
		saveGameButton.setText("Save Game");
		layout.addView(saveGameButton, getRL(150,600));	
		setContentView(layout);
		dealCardsBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0)
			{
				redealt = false;
				dealCards();
			}
		});

		
		saveGameButton.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0)
			{
				SaveHands();

				if (redealt)
					toast("Game already redealt");
				else
				{
					redealt = true;
					toast("Hit 'Deal Cards' to redeal the game");
					shoe.reDeal();
				}
			}
		});
		
		
        for (int i = 0; i < numPlayers - 1; i++) // create 'numPlayers' number of new players.
            players.add(new Player(30 + i * 150, 240, shoe, this, numPlayers - 1 == i, i, layout));

        // Dealer hand --
        players.add(new Player(numPlayers * 50, 30, shoe, this, true, numPlayers - 1, layout));
    }
    
    public void toast(String text)
    {
    	Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    int dealCounter;

	private void dealCards()
	{
		shoe.newGame();
		for (Player p: players)
		{
			p.DiscardHands();
			p.MakeHand();
		}
		player = players.get(0);
		dealer = players.get(players.size() - 1);
		dealCounter = 0;
		handler.post(dealCard);
		
	}

	public Player curPlayer()
	{
		return player;
	}
	
	private Runnable dealCard = new Runnable() {
		public void run() {
			Player p = players.get(dealCounter++ % numHands);
			if (dealCounter <= numHands)
				p.DealOne();
			else
				p.DealTwo();
			if (dealCounter < numHands * 2)
				handler.postDelayed(this, msInc);
			else
				postDeal();
		}
	};

	private void postDeal() {
		dealer = players.get(players.size() - 1);
		dealerHand = dealer.curHand();
				
		if (dealerHand.isFirstAce())	// Offer insurance if dealer shows an Ace
			/*doInsurance()*/;
				
		if (dealerHand.isBlackjack())	// If dealer has Blackjack, do dealer stuff
			doDealer();

		// Mark hittable the first non-Blackjack hand.
		// If all hands are Blackjack hands, it's time for the dealer.		
		boolean anyhittable = false;
		curHandX = 0;
		for (Player p: players)
		{
			if (p == dealer || p.isPlayable())
			{
				player = p;
				break;
			}
			curHandX++;
		}
		if (curHandX == players.size() - 1)
			doDealer();
	}

	public void allowHitNextHand()
	{
		while (true)
		{
			Player p = players.get(++curHandX);
			if (p != dealer)
			{
				if (!p.isPlayable())
					continue;
				player = p;
			}
			else
				doDealer();
			break;
		}
		//if (curHandX == numHands - 1)
			//doDealer();
	}
    
	  // Called after last player is dealt and blackjacked, busted, or stayed.
	  private void doDealer()
	     {
	         Hand h = dealerHand;
	         h.setFacedown(false);
	         //h.faceUp();
	         h.ShowHand();
	         while (dealerRulesHit()) // Process the dealer hand.
	             h.DealOne();
	         // Determine the dealer's results for use in Player.java EvaluateHand().
	         dealerHandResult = dealer.curHand().EvaluateHand();
	         // Index through Player.java hands[] array to get player results
			for (Player p : players)
	         {
				if (p == dealer)
					break;
	            p.setDealerBlackJack(dealerBlackJack);
	            p.CalcWinnings(0, dealerHandResult); // Calculate who won and determine payouts or losses.
	            p.setDealerBlackJack(false); 
	         }
	         dealerBlackJack = false;
	     }
	  
	  private boolean dealerRulesHit()
	     {
	         // Parse HandValue and hit on Hard 16 or lower, Soft 17 or lower
	         Hand h = dealerHand;
	         if (h.isBlackjack())
	             return false;

	         // Hit soft 17, hard 16
	         if (h.isSoft())
	             return (h.getHValue() + 10 <= 17);
	         else
	             return (h.getHValue() <= 16);
	     }
	  
	  public void SaveHands()
	  {
	      String path = "/data/data/blackjackdev.java/savehands" + "//savehands.txt";

	      try {
	          BufferedWriter file = new BufferedWriter(new FileWriter(path));
	          for (Player p: players)
	          {
	              p.SaveHands(file);
	          }
	          file.close();
	      } catch (IOException ex) {
	          ex.printStackTrace();
	      }
	  }

    	
    	private RelativeLayout.LayoutParams getRL(int x, int y)
    	{
    		RelativeLayout.LayoutParams rl = new
    			RelativeLayout.LayoutParams(
    					RelativeLayout.LayoutParams.WRAP_CONTENT,
    					RelativeLayout.LayoutParams.WRAP_CONTENT);
    		rl.topMargin = y;
    		rl.leftMargin = x;
    		return rl;
    	}
    
    	public RelativeLayout getLayout()
    	{
    		return layout;
    	}
    	
    	 public void RedealHandsExact(String path)
    	 {
    	     String l;
    	     int cardsHit = 0;
    	     ArrayList<Integer> cardsHitArrayList = new ArrayList<Integer>();
    	     try 
    	     {
    	         BufferedReader file = new BufferedReader(new FileReader(path));
    	     
    	         while ((l = file.readLine()) != null)
    	         {
    	             if (l.length() < 3)
    	                 continue;
    	             if ((l.startsWith("hand")))
    	                 while (true)
    	                 {
    	                     l = file.readLine();
    	                     if(l == null)
    	                         break;
    	                     if (l.length() < 3)
    	                         continue;
    	                     if(l.startsWith("player"))
    	                         break;
    	                     cardsHit++;
    	                 }
    	             cardsHitArrayList.add(cardsHit); 
    	             cardsHit = 0;
    	         }
    	         
    	         file.close();
    	     } catch (IOException ex) {
    	         ex.printStackTrace();
    	     }
    	     dealCards();
    	     int x = 0;
    	     int y = 0;
    	     int i = 0;
    	     for (Player player: players)
    	     {
    	         i++;
    	         {
    	             y = Integer.valueOf(cardsHitArrayList.get(i).toString());
    	             y = x;
    	             while(x++ < Integer.valueOf(cardsHitArrayList.get(i).toString()))
    	             {
    	                 y = Integer.valueOf(cardsHitArrayList.get(i).toString());
    	                 if(x > 2)
    	                     player.ReHitCardsExact(); 
    	             }
    	         x = 0;
    	         player.ReHitCardsExactStay();
    	         }
    	     }
    	 }
}
