package blackjackdev.java;

public enum Suit { Clubs, Diamonds, Hearts, Spades }