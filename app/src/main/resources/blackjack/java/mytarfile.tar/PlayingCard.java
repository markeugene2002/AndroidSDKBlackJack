

package blackjackdev.java;

public class PlayingCard {



	/**
	 *
	 * @author Mark-Laptop
	 */

	private Suit suit;
	private Value value;
	private String path;
	private boolean testCard = false;

	public PlayingCard(Suit s, Value v, String imgFmt)
	{
		suit = s;
		value = v;
		path = String.format(imgFmt, ToString());
	}

	public int CardSuit()
	{
		return this.suit.ordinal();
	}

	public Suit CardSuitEnum()
	{
		return this.suit;
	}

	public int CardValue()
	{
		return this.value.ordinal();
	}

	public Value CardValueEnum()
	{
		return this.value;
	}

	public String CardPath()
	{
		return path;
	}

	public void SetTestCard(boolean what)
	{
		testCard = what;
	}

	public boolean IsTestCard()
	{
		return testCard;
	}

	public String ToString()
	{
		String result = String.format("%s of %s", value, suit);
		return result;
	}

}
