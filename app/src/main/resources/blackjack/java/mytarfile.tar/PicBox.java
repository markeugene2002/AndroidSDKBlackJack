/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjackdev.java;


import blackjackdev.java.R.drawable;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

/**
 *
 * @author Mark-Laptop
 */
public class PicBox extends ImageButton {
	private static final String cardBackPath = "/data/data/blackjackdev.java/cards/CardBack.png";
	private int x;
	private int y;
	private Hand h;
	private PlayingCard pCard;
	private RelativeLayout.LayoutParams rl;
	private boolean facedown = false;

	public PicBox(int myX, int myY, Shoe shoe, Hand myHand)
	{
		super(myHand.handThat());
		h = myHand;
		x = myX;
		y = myY;

		pCard = shoe.GetCard();
		setFace();
		this.setPadding(0, 0, 0, 0);
		this.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0)
			{
				h.Hand_Click('L');
				//doClick(arg0);
			}
		});
		
		this.setOnLongClickListener(new OnLongClickListener() {          
			public boolean onLongClick(View arg0) {             
				// TODO Auto-generated method stub 
				h.Hand_Click('R');
			return true;         
			}     
		}); 

		rl = getRL(x, y);
	}

	public Hand getHand()
	{
		return h;
	}

	public void show(RelativeLayout layout)
	{
		layout.addView(this, rl);
	}

	public PlayingCard GetPCard()
	{
		return pCard;
	}

	public int GetX()
	{
		return x;
	}

	public int GetY()
	{
		return y;
	}

	public void setFace()
	{
		String path = new String();
		if (facedown)
			path = cardBackPath;
		else
			path = pCard.CardPath();
		setImageBitmap(BitmapFactory.decodeFile(path));
		h.setValueVisible(!facedown);
	}

	public void Facedown(boolean what)
	{
		facedown = what;
	}

	private RelativeLayout.LayoutParams getRL(int x, int y)
	{
		RelativeLayout.LayoutParams rl = new
			RelativeLayout.LayoutParams(
					RelativeLayout.LayoutParams.WRAP_CONTENT,
					RelativeLayout.LayoutParams.WRAP_CONTENT);
		rl.topMargin = y;
		rl.leftMargin = x;
		return rl;
	}
}


