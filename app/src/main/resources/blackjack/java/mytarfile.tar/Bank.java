/*
 /*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjackdev.java;

/**
 *
 * @author Mark
 */


import android.content.Context;
import android.widget.RelativeLayout;
import android.widget.TextView;


public class Bank extends TextView{
    private int x;
    private int y;
    private BlackJackDevActivity that;
    private int balance = 0;
    private RelativeLayout layout;
    private RelativeLayout.LayoutParams rl;
    
    public Bank(Context context){
    	super(context);
    	
    }
    public Bank(int myX, int myY, BlackJackDevActivity myThat, Context context, RelativeLayout myLayout){
    	super(context);
        x = myX;
        y = myY;
        layout = myLayout;
        rl = getRL(x, y);
        that = myThat;
        setText((Integer.toString(balance)));
        layout.addView(this, rl);
    }
    
	/*
    public void DiscardBank()
    {
        //that.remove(this);
    }
	*/

    public int withdraw(int withdrawal)
    {
        int amountWithdrawn = withdrawal;
     
        assert(withdrawal >= 0);
        if (withdrawal > balance)
            amountWithdrawn = balance;
        balance -= amountWithdrawn;
        setText(Integer.toString(balance));
        return amountWithdrawn;
    }

    public int deposit(int deposit)
    {
        assert(deposit >= 0);
        balance += deposit;
        setText(Integer.toString(balance));
        return deposit;
    }
    
    public int getBalance()
    {
        return balance;
    }
/*
    public void SetColor(Color color)
    {
        setBackground(color);
    }
    */
    
	private RelativeLayout.LayoutParams getRL(int x, int y)
	{
		RelativeLayout.LayoutParams rl = new
			RelativeLayout.LayoutParams(
					RelativeLayout.LayoutParams.WRAP_CONTENT,
					RelativeLayout.LayoutParams.WRAP_CONTENT);
		rl.topMargin = y;
		rl.leftMargin = x;
		return rl;
	}
    
}
